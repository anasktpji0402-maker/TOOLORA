# Build verification

This package is prepared for a normal Node/npm host deployment. Dependency versions are pinned in `package.json` for reproducible installs.

**Environment limitation:** this ChatGPT runtime currently cannot resolve `registry.npmjs.org`, so `npm install` could not complete here and a local production build could not be verified in this runtime.

On a machine/host with npm internet access:

```bash
npm install
npm run build
npm run preview
```

For CI/production, commit the generated `package-lock.json` after the first successful `npm install`, then use `npm ci` for reproducible deployments.
