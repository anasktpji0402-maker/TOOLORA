# TOOLORA — Hosting quick start

## Vercel / Netlify / Cloudflare Pages
- Framework: Vite
- Build command: `npm run build`
- Output directory: `dist`
- Node: 18.18+ (20+ recommended)
- Install command: `npm install` (or `npm ci` after committing package-lock.json)

## Environment variables
Copy `.env.example` to your host's environment settings. Do not put private AI secrets in `VITE_*` variables.

## SPA routing
Configure the host to serve `index.html` for application routes such as `/tools/emi-calculator` and `/guides/emi`.

## First deployment
1. Upload/extract the project.
2. Run `npm install`.
3. Run `npm run build`.
4. Publish `dist/`.
5. Test `/`, `/tools`, `/tools/emi-calculator`, `/categories`, `/guides` and legal pages.

The source includes no fake API credentials and no dependency `node_modules` folder.
